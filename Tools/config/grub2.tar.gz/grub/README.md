个人对 grub 启动项的美化配置。

`grub`是配置文件，复制到`/etc/default`,使用命令`grub2-mkconfig -o /boot/grub2/grub.cfg`更新。

`Tela-1080p.tar.xz` 是 grub 的主题，另外一个是 grub2 的主题。