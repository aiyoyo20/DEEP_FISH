个人的 fcitx5 配置，包含了 rime 输入法，一个明主题（Material-Color）、一个暗色主题（fcitx5-dark-transparent）。

需要提前安装配置并启用 fcitx5 ,然后将所有文件`themes`和`rime`复制到`~/.local/share/fcitx5/`中重启 fcitx5 即可。

`.pam_environment`复制到用户家目录。

rime 输入法进行了一些调整，删除了不需要的可选项，比如繁体的输入，只保留了`简化字`的选项，也就只有一个选项了。不需要在调用的使用去切换成简体，因为默认是繁体。