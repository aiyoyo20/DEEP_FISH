# minikube

This plugin provides completion for [minikube](https://github.com/kubernetes/minikube).

To use it, add `minikube` to the plugins array in your zshrc file.

```
plugins=(... minikube)
```
